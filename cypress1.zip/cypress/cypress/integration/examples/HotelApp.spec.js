/// <reference types="Cypress" />

context('login test', () => {
  
    it('should login and go to the booking page', () => {
     cy.visit('http://adactin.com/HotelAppBuild2/')
     cy.get('#username').type('cerenanirmal')
     cy.get('#password').type('Cerena@@87')
     cy.get('#login').click()
     
  })
})