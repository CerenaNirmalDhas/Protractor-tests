/// <reference types="Cypress" />

context('login test', () => {
  
    it('should login and go to the booking page', () => {
     cy.visit('http://adactin.com/HotelAppBuild2/')
     cy.get('#username').type('cerenanirmal')
     cy.get('#password').type('Cerena@@87')
     cy.get('#login').click()
     cy.get('.login_title').should('contain','Search Hotel')
     cy.get('#location').select('London')
     cy.get('#location').should('contain','London')
     cy.get('#hotels').select('Hotel Sunshine')
     cy.get('#room_type').select('Double')
     cy.get('#datepick_in').clear()
     cy.get('#datepick_in').type('15/04/2019')
     cy.get('#datepick_out').clear()
     cy.get('#datepick_out').type('16/04/2019')
     cy.get('#Submit').click()
     cy.get('#radiobutton_0').click()
     cy.get('#hotel_name_0').should('have.value','Hotel Sunshine')
     cy.get('#location_0').should('have.value','London')

  })
})